#11-4-2012 MRC-Epid JHZ

### note we need to tidy up to compile the standalone/commandline version

mv Q67_qdscore.c stplugin.* ..
make

### once that is done we can build it as Stata plugin as follows

sh stata_qdscore.sh
stata -b do stata_qdscore.do
cat stata_qdscore.log
