#10-4-2012 MRC-Epid JHZ

gcc -shared -DSYSTEM=OPUNIX -fPIC -I. -o stata_qdscore.plugin \
     stplugin.c c/Q67_qdscore_2011_5_0.c c/Q67_qdscore_2011_5_1.c c/utils.c Q67_qdscore.c
